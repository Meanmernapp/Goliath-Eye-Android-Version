package com.example.goliatheye.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import androidx.annotation.Nullable;

import com.example.goliatheye.R;


public class TurnedOffService extends Service {

    NotificationManager notificationManager;
    boolean run = true;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent.getAction().equals("TURNED_OFF")){
            handler.post(runNotification);
            run = true;
        } else if (intent.getAction().equals("TURNED_ON")){
            if (notificationManager!=null) {
                notificationManager.cancel(2535);
            }
            run = false;
            stopSelf();
        }
        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    Handler handler = new Handler(Looper.getMainLooper());

    Runnable runfuck = new Runnable() {
        @Override
        public void run() {
            handler.post(runNotification);
        }
    };

    Runnable runNotification = () -> {

        if (run){
            ShowNotification();
            handler.postDelayed(runfuck, 30000);
        }
    };


    public void ShowNotification(){
        notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder builder = new Notification.Builder(this);
        builder.setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("Service is Stopped")
                .setContentText("Service is not running. Run it from application")
                .setPriority(Notification.PRIORITY_HIGH)
                .setCategory(Notification.CATEGORY_MESSAGE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String channelId = "REMINDERS";
            NotificationChannel channel = new NotificationChannel(channelId,
                    "Reminder",
                    NotificationManager.IMPORTANCE_DEFAULT);
            notificationManager.createNotificationChannel(channel);
            builder.setChannelId(channelId);
        }
        notificationManager.notify(2535, builder.build());
        startForeground(2535, builder.build());
    }
}
