package com.example.goliatheye.Constructors;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Logg implements Serializable {

    @SerializedName("userId")
    int userId;

    @SerializedName("action")
    String action;

    @SerializedName("logTime")
    String logTime;

    @SerializedName("userName")
    String userName;


    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getLogTime() {
        return logTime;
    }

    public void setLogTime(String logTime) {
        this.logTime = logTime;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}

