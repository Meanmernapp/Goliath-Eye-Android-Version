package com.example.goliatheye.Utils;

import android.util.Log;

import com.example.goliatheye.Constructors.GettingInvites;
import com.example.goliatheye.Constructors.Logg;
import com.example.goliatheye.Constructors.Login;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class JSONResponse implements Serializable {

    @SerializedName("responsecode")
    public int responsecode;

    @SerializedName("messages")
    public String messages;

    @SerializedName("message")
    public String message;

    public ArrayList<Logg> getLogg = new ArrayList<>();

    @SerializedName("data")
    public ArrayList<GettingInvites> gettingInvites = new ArrayList<>();


}
