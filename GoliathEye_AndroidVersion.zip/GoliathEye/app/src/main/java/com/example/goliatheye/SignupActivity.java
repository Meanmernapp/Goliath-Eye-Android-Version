package com.example.goliatheye;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.goliatheye.Constructors.ForgotPassword;
import com.example.goliatheye.Constructors.Login;
import com.example.goliatheye.Constructors.Menu;
import com.example.goliatheye.Constructors.Register;
import com.example.goliatheye.Utils.APIClient;
import com.example.goliatheye.Utils.APIInterface;
import com.example.goliatheye.Utils.JsonUtils;
import com.google.gson.Gson;
import com.tmclients.technoutils.Utilities;

import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Pattern;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignupActivity extends AppCompatActivity {
    Button btn_register;
    TextView txt_alreadyaccount,txt_signin;
    EditText edt_name,edt_email,edt_phoneNumber,edt_password,edt_confirmpassword;
    Utilities utilities;
    ArrayList<EditText> register_section;
    APIInterface apiInterface;
    ProgressDialog progress;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        btn_register= findViewById(R.id.btn_register);
        txt_signin= findViewById(R.id.txt_signin);
        txt_alreadyaccount= findViewById(R.id.txt_alreadyaccount);
        edt_name= findViewById(R.id.edt_name);
        edt_email= findViewById(R.id.edt_email);
        edt_phoneNumber= findViewById(R.id.edt_phoneNumber);
        edt_password= findViewById(R.id.edt_password);
        edt_confirmpassword= findViewById(R.id.edt_confirmpassword);
        utilities= new Utilities(this);
        register_section= new ArrayList<>();
        apiInterface = APIClient.getClient().create(APIInterface.class);
        progress = new ProgressDialog(SignupActivity.this);
        progress.setMessage("loading");
        progress.setCancelable(false);
        register_section.add(edt_name);
        register_section.add(edt_email);
        register_section.add(edt_phoneNumber);

        register_section.add(edt_password);
        register_section.add(edt_confirmpassword);

        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (utilities.EdittextFieldsValidationResult(register_section).equals("Success")) {

                    if (isValidEmailId(edt_email.getText().toString().trim())) {

                    if (JsonUtils.isNetworkAvailable(SignupActivity.this)) {
                        if (TextUtils.isEmpty(edt_phoneNumber.getText().toString())) {
                            Toast.makeText(getApplicationContext(), "Please enter a phone number first", Toast.LENGTH_SHORT).show();
                        } else if (!edt_password.getText().toString().equals(edt_confirmpassword.getText().toString())) {
                            Toast.makeText(getApplicationContext(), "Password not matchable", Toast.LENGTH_SHORT).show();

                        } else {
                            if (progress!=null){
                                progress.show();
                            }
                            Register register = new Register();
                            register.setEmail(edt_email.getText().toString());
                            register.setName(edt_name.getText().toString());
                            register.setPassword(edt_password.getText().toString());
                            register.setPhoneNumber(edt_phoneNumber.getText().toString());

                            apiInterface.RegisterUser(register).enqueue(new Callback<Register>() {
                                @Override
                                public void onResponse(Call<Register> call, Response<Register> response) {
                                    Register result = response.body();

                                    int statusCode = response.code();

                                  //  Toast.makeText(SignupActivity.this, String.valueOf(statusCode), Toast.LENGTH_SHORT).show();

                                    if (statusCode == 200) {
                                        progress.dismiss();
                                        Intent intent = new Intent(SignupActivity.this, VerificationActivity.class);
                                        intent.putExtra("USER_EMAIL", edt_email.getText().toString());
                                        startActivity(intent);
                                        finishAffinity();
                                        Toast.makeText(SignupActivity.this, result.message, Toast.LENGTH_SHORT).show();
                                    } else if (statusCode==400){
                                        progress.dismiss();
                                        Gson gson = new Gson();
                                        Register errorResponse = null;
                                        try {
                                        errorResponse = gson.fromJson(response.errorBody().string(), Register.class);
                                        } catch (IOException e) {
                                        e.printStackTrace();
                                        }
                                        LoginFailedpopup(errorResponse.message);

                                    }else {
                                        if (progress!=null){
                                            progress.dismiss();
                                        }
                                        LoginFailedpopup("REGISTRATION FAILED");
                                    }
                                }

                                @Override
                                public void onFailure(Call<Register> call, Throwable t) {
                                    if (progress!=null){
                                        progress.dismiss();
                                    }
                                    LoginFailedpopup("REGISTRATION FAILED");
                                }
                            });
                        }
                    } else {
                        Toast.makeText(SignupActivity.this, "Check internet connection", Toast.LENGTH_SHORT).show();
                    }
                }else {
                        Toast.makeText(SignupActivity.this, "Invalid Email Address", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        txt_alreadyaccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SignupActivity.this,LoginActivity.class);
                startActivity(intent);
                finishAffinity();
            }
        });

        txt_signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SignupActivity.this,LoginActivity.class);
                startActivity(intent);
                finishAffinity();
            }
        });
    }

    private boolean isValidEmailId(String email){

        return Pattern.compile("^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$").matcher(email).matches();
    }

    public void LoginFailedpopup(String txt_1){
        final Dialog dialog = new Dialog(SignupActivity.this);
        dialog.setContentView(R.layout.row_dialogs);
        Button btn_yes =  dialog.findViewById(R.id.btn_logout);
        Button btn_later =  dialog.findViewById(R.id.btn_later);
        TextView txt_dialog_header =  dialog.findViewById(R.id.txt_dialog_header);
        TextView txt_dialog_main =  dialog.findViewById(R.id.txt_dialog_main);

        btn_yes.setText("YES");
        txt_dialog_header.setText(txt_1);
        txt_dialog_main.setText("Do you want to try again ?");

        btn_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dialog.dismiss();

            }
        });
        btn_later.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

}