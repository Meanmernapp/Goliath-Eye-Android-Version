package com.example.goliatheye;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import com.example.goliatheye.Utils.Constant;
import com.tmclients.technoutils.PreferenceHelper;

public class SplashActivity extends AppCompatActivity {
    PreferenceHelper preferenceHelper;
    boolean isloggin;
    int userid=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        preferenceHelper= new PreferenceHelper(this,"GOLIATH APPLICATION");
        isloggin=  preferenceHelper.GetBoolean("IS_LOGGED_IN",false);
        userid= preferenceHelper.GetInt("USER_ID", 0);


        int secondsDelayed = 1;
        new Handler().postDelayed(new Runnable() {
            public void run() {

                if (isloggin){
                    Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                }else{
                    Intent intent = new Intent(SplashActivity.this, LoginActivity.class);
                    startActivity(intent);
                    finish();
                }


            }
        }, secondsDelayed * 2000);

    }
}