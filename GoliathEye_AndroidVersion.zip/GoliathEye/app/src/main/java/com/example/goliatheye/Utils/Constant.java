package com.example.goliatheye.Utils;

public class Constant {

    public static  int USERID = 0;

}
