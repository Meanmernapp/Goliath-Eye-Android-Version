package com.example.goliatheye;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.goliatheye.Constructors.Register;
import com.example.goliatheye.Constructors.SS;
import com.example.goliatheye.Utils.APIClient;
import com.example.goliatheye.Utils.APIInterface;
import com.google.gson.Gson;
import com.poovam.pinedittextfield.SquarePinField;

import java.io.IOException;

public class VerificationActivity extends AppCompatActivity {
    SquarePinField squarePinField;
    Button btn_verify;
    String code;
    APIInterface apiInterface;
    String USER_EMAIL;
    public ProgressDialog progress;
    TextView txt_email_desc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verification);

        Intent intent = getIntent();
        USER_EMAIL = intent.getStringExtra("USER_EMAIL");

        squarePinField = findViewById(R.id.sqr_code);
        btn_verify = findViewById(R.id.btn_verify);
        txt_email_desc = findViewById(R.id.txt_email_desc);

        txt_email_desc.setText("Verification code has been sent on " + USER_EMAIL + " email.");

        apiInterface = APIClient.getClient().create(APIInterface.class);

        progress = new ProgressDialog(VerificationActivity.this);
        progress.setMessage("loading");
        progress.setCancelable(false);

        btn_verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                code = squarePinField.getText().toString();
                if (TextUtils.isEmpty(code)) {
                    Toast.makeText(VerificationActivity.this, "Please enter code first", Toast.LENGTH_SHORT).show();
                } else {
                    progress.show();
                    GetVerificationCode(USER_EMAIL,code);
                }
            }
        });

    }

    public void GetVerificationCode(String email, String code){
        apiInterface.GetVerified(email,code).enqueue(new retrofit2.Callback<SS>() {
            @Override
            public void onResponse(retrofit2.Call<SS> call, retrofit2.Response<SS> response) {
                SS result = response.body();

                int statusCode = response.code();

                if (statusCode == 200) {

                    progress.dismiss();

                    Toast.makeText(VerificationActivity.this, result.message, Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(VerificationActivity.this, LoginActivity.class);
                    startActivity(intent);
                    finishAffinity();
                }else if (statusCode==400){
                    progress.dismiss();
                    Gson gson = new Gson();
                    Register errorResponse = null;
                    try {
                        errorResponse = gson.fromJson(response.errorBody().string(), Register.class);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    DialogMessage(errorResponse.message);
                }else {

                    progress.dismiss();
                    DialogMessage("Invalid code");
                }
            }

            @Override
            public void onFailure(retrofit2.Call<SS> call, Throwable t) {
                call.cancel();
                progress.dismiss();
                Toast.makeText(VerificationActivity.this, "server error, try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void DialogMessage(String txt_1){
        final Dialog dialog = new Dialog(VerificationActivity.this);
        dialog.setContentView(R.layout.row_dialogs);
        Button btn_logout =  dialog.findViewById(R.id.btn_logout);
        Button btn_later =  dialog.findViewById(R.id.btn_later);
        TextView txt_dialog_header =  dialog.findViewById(R.id.txt_dialog_header);
        TextView txt_dialog_main =  dialog.findViewById(R.id.txt_dialog_main);

        btn_logout.setText("TRY AGAIN");
        txt_dialog_header.setText("VERIFICATION FAILED");
        txt_dialog_main.setText(txt_1);

        btn_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        btn_later.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }


}