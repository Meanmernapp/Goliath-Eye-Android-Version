package com.example.goliatheye;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import com.tmclients.technoutils.PreferenceHelper;

public class ProfileActivity extends AppCompatActivity {

    TextView edt_name,edt_email,edt_phoneNumber,edt_password;
    PreferenceHelper preferenceHelper;
    String USERNAME,EMAIL,PHONE_NUMBER,PASSWORD;
    boolean isloggin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);


        edt_name= findViewById(R.id.edt_name);
        edt_email= findViewById(R.id.edt_email);
        edt_phoneNumber= findViewById(R.id.edt_phoneNumber);
        edt_password= findViewById(R.id.edt_password);
        preferenceHelper= new PreferenceHelper(this,"GOLIATH APPLICATION");

        USERNAME=    preferenceHelper.GetString("USERNAME", null);
        EMAIL=   preferenceHelper.GetString("EMAIL", null);
        PHONE_NUMBER= preferenceHelper.GetString("PHONE_NUMBER", null);
        PASSWORD= preferenceHelper.GetString("PASSWORD", null);
        isloggin=  preferenceHelper.GetBoolean("IS_LOGGED_IN",false);
        if (isloggin){
            if (USERNAME!=null){
                edt_name.setText(USERNAME);
            } if (EMAIL!=null){
                edt_email.setText(EMAIL);
            } if (PHONE_NUMBER!=null){
                edt_phoneNumber.setText(PHONE_NUMBER);
            } if (PASSWORD!=null){
                edt_password.setText(PASSWORD);
            }
        }

    }
}