package com.example.goliatheye.Constructors;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class GettingInvites implements Serializable {


    @SerializedName("message")
    public String message;

    @SerializedName("id")
    int id;

    @SerializedName("adminId")
    int adminId;

    @SerializedName("inviteStatus")
    String inviteStatus;

    @SerializedName("userEmail")
    String userEmail;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAdminId() {
        return adminId;
    }

    public void setAdminId(int adminId) {
        this.adminId = adminId;
    }

    public String getInviteStatus() {
        return inviteStatus;
    }

    public void setInviteStatus(String inviteStatus) {
        this.inviteStatus = inviteStatus;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }
}
