package com.example.goliatheye;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.goliatheye.Adapters.SlidingImage_Adapter;
import com.example.goliatheye.Constructors.SS;
import com.example.goliatheye.Utils.APIClient;
import com.example.goliatheye.Utils.APIInterface;
import com.tmclients.technoutils.PreferenceHelper;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GalleryActivity extends AppCompatActivity {

    ViewPager viewPager;
    PreferenceHelper preferenceHelper;
    APIInterface apiInterface;
    SlidingImage_Adapter adapter;
    ArrayList<SS> data;
    int userid;
    boolean isAdmin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);

        viewPager= findViewById(R.id.viewPage);

        Toolbar toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("Gallery");

        apiInterface = APIClient.getClient().create(APIInterface.class);
        preferenceHelper= new PreferenceHelper(this,"GOLIATH APPLICATION");
        isAdmin=  preferenceHelper.GetBoolean("IS_ADMIN",false);
        Intent intent = getIntent();
        userid = intent.getIntExtra("ID",0);

        data= new ArrayList<>();

        GettingGalleryImages(userid);
    }

    public void GettingGalleryImages(int user_id){
        apiInterface.GetScreenShots(user_id).enqueue(new Callback<List<SS>>() {
            @Override
            public void onResponse(Call<List<SS>> call, Response<List<SS>> response) {
                List<SS> result = response.body();

                int statusCode = response.code();

                if (statusCode == 200) {

                    data.addAll(result);
                   adapter  = new SlidingImage_Adapter(GalleryActivity.this, data);
                    viewPager.setAdapter(adapter);
                }else {
                    Toast.makeText(GalleryActivity.this, "Try again.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<SS>> call, Throwable t) {
                call.cancel();
                Toast.makeText(GalleryActivity.this, "server error", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected (MenuItem item){
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}