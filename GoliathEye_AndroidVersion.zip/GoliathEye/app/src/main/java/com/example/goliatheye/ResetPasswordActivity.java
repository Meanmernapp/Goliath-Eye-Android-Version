package com.example.goliatheye;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.goliatheye.Constructors.ForgotPassword;
import com.example.goliatheye.Constructors.Login;
import com.example.goliatheye.Constructors.Menu;
import com.example.goliatheye.Utils.APIClient;
import com.example.goliatheye.Utils.APIInterface;
import com.example.goliatheye.Utils.JSONResponse;

import java.util.ArrayList;
import java.util.regex.Pattern;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ResetPasswordActivity extends AppCompatActivity {

    Button btn_sendEmail;
    TextView txt_signin,txt_signup;
    EditText edt_email;
    APIInterface apiInterface;
    ProgressDialog progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rest_password);

        btn_sendEmail= findViewById(R.id.btn_sendEmail);
        txt_signin= findViewById(R.id.txt_signin);
        txt_signup= findViewById(R.id.txt_signup);
        edt_email= findViewById(R.id.edt_email);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        progress = new ProgressDialog(ResetPasswordActivity.this);
        progress.setMessage("Please Wait.");
        progress.setCancelable(false);

        btn_sendEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (edt_email.getText().toString().isEmpty()){
                    Toast.makeText(ResetPasswordActivity.this, "Enter your email.", Toast.LENGTH_SHORT).show();

                }
                else if(isValidEmailId(edt_email.getText().toString().trim())){
                    if (progress!=null){
                        progress.show();
                    }
                    ForgotPassword forgotPassword = new ForgotPassword();
                    forgotPassword.setEmail(edt_email.getText().toString());

                    apiInterface.ForgotPassword(forgotPassword).enqueue(new Callback<ForgotPassword>() {
                        @Override
                        public void onResponse(Call<ForgotPassword> call, Response<ForgotPassword> response) {
                            ForgotPassword result = response.body();

                            int statusCode = response.code();

                            if (statusCode == 200) {
                                progress.dismiss();
                                Toast.makeText(ResetPasswordActivity.this, result.message, Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(ResetPasswordActivity.this, LoginActivity.class);
                                startActivity(intent);
                                finishAffinity();


                            } else {
                                if (progress!=null){
                                    progress.dismiss();
                                }

                                CheckEmail();

                            }
                        }

                        @Override
                        public void onFailure(Call<ForgotPassword> call, Throwable t) {
                            if (progress!=null){
                                progress.dismiss();
                            }
                            CheckEmail();
                        }
                    });

                }else{
                    Toast.makeText(getApplicationContext(), "InValid Email Address.", Toast.LENGTH_SHORT).show();
                }

            }
        });

        txt_signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ResetPasswordActivity.this,LoginActivity.class);
                startActivity(intent);
                finishAffinity();
            }
        });

        txt_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ResetPasswordActivity.this,SignupActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private boolean isValidEmailId(String email){

        return Pattern.compile("^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$").matcher(email).matches();
    }

    public void CheckEmail(){
        final Dialog dialog = new Dialog(ResetPasswordActivity.this);
        dialog.setContentView(R.layout.row_dialogs);
        Button btn_logout =  dialog.findViewById(R.id.btn_logout);
        Button btn_later =  dialog.findViewById(R.id.btn_later);
        TextView txt_dialog_header =  dialog.findViewById(R.id.txt_dialog_header);
        TextView txt_dialog_main =  dialog.findViewById(R.id.txt_dialog_main);

        btn_logout.setText("YES");
        txt_dialog_header.setText("RESET PASSWORD");
        txt_dialog_main.setText("Email not found, do you want to try again ?");

        btn_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dialog.dismiss();

            }
        });
        btn_later.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

}