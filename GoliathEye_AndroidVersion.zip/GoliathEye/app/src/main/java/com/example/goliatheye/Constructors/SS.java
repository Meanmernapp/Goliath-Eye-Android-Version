package com.example.goliatheye.Constructors;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class SS implements Serializable {

    @SerializedName("userId")
    int userId;

    @SerializedName("imagePath")
    String imagePath;

    @SerializedName("message")
   public String message;

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
}
