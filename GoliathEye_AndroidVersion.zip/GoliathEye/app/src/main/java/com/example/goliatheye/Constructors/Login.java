package com.example.goliatheye.Constructors;

import android.util.Log;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class Login implements Serializable {

    public int responsecode;
    @SerializedName("message")
    public String message;

    @SerializedName("data")
   public Menu data;

    @SerializedName("id")
    int id;

    @SerializedName("name")
    String name;

    @SerializedName("phoneNumber")
    String phoneNumber;

    @SerializedName("email")
    String email;
    @SerializedName("password")
    String password;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }



    @Override
    public String toString() {
        return "data{" +
                "id=" + id +
                ", email='" + email + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", password='" + password + '\'' +
                '}';
    }

//    public List<Menu> getData() {
//        Log.e("in get data of contact", data.toString());
//        return data;
//    }


//    @SerializedName("id")
//    String id;
//
//    @SerializedName("createdAt")
//    String createdAt;
//
//    @SerializedName("email")
//    String email;
//
//
//    @SerializedName("name")
//    String name;
//
//    @SerializedName("password")
//    String password;
//
//    @SerializedName("phoneNumber")
//    String phoneNumber;
//
//    public String getId() {
//        return id;
//    }
//
//    public void setId(String id) {
//        this.id = id;
//    }
//
//    public String getCreatedAt() {
//        return createdAt;
//    }
//
//    public void setCreatedAt(String createdAt) {
//        this.createdAt = createdAt;
//    }
//
//    public String getEmail() {
//        return email;
//    }
//
//    public void setEmail(String email) {
//        this.email = email;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public String getPassword() {
//        return password;
//    }
//
//    public void setPassword(String password) {
//        this.password = password;
//    }
//
//    public String getPhoneNumber() {
//        return phoneNumber;
//    }
//
//    public void setPhoneNumber(String phoneNumber) {
//        this.phoneNumber = phoneNumber;
//    }
}
