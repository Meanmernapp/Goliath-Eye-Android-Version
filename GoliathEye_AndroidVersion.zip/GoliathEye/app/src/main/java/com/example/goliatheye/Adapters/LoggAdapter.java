package com.example.goliatheye.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.goliatheye.Constructors.Logg;
import com.example.goliatheye.R;


import java.util.ArrayList;
import java.util.List;

public class LoggAdapter extends RecyclerView.Adapter<LoggAdapter.ViewHolder> {

    private Context context;
    private ArrayList<Logg> data;
    public LoggAdapter(Context context, ArrayList<Logg> data){
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_logg, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final Logg singleitem = data.get(position);

        holder.txt_userName.setText(singleitem.getUserName());
        holder.txt_loggTime.setText(singleitem.getLogTime());
        holder.txt_action.setText(singleitem.getAction());

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView txt_userName,txt_loggTime,txt_action;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txt_userName = itemView.findViewById(R.id.txt_userName);
           txt_action = itemView.findViewById(R.id.txt_action);
            txt_loggTime = itemView.findViewById(R.id.txt_loggTime);

        }
    }
}
