package com.example.goliatheye;


import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.goliatheye.Constructors.Logg;
import com.example.goliatheye.Constructors.SendingInvitations;
import com.example.goliatheye.Utils.APIClient;
import com.example.goliatheye.Utils.APIInterface;
import com.example.goliatheye.Utils.JsonUtils;
import com.example.goliatheye.service.ScreenCaptureService;
import com.example.goliatheye.service.TurnedOffService;
import com.google.gson.Gson;
import com.tmclients.technoutils.PreferenceHelper;
import com.tmclients.technoutils.Utilities;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends Activity {

    TextView txt_invites,txt_logout,txt_admin_accesss,txt_logg,txt_start_recording,txt_stop_recording,txt_status,txt_profile;
    PreferenceHelper preferenceHelper;
    APIInterface apiInterface;
    int userid;
    boolean isAdmin;
    Utilities utilities;
    ArrayList<EditText> invitation_section;
    public static final String MESSAGE_STATUS = "MainActivity";
    private static final int REQUEST_CODE = 100;

    PeriodicWorkRequest workRequest;
    final WorkManager mWorkManager = WorkManager.getInstance();
    ProgressDialog progress;
    boolean IS_RECORDING_START;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        preferenceHelper= new PreferenceHelper(this,"GOLIATH APPLICATION");
        txt_logout= findViewById(R.id.txt_logout);
        txt_invites= findViewById(R.id.txt_invites);
        txt_status= findViewById(R.id.txt_status);
        txt_admin_accesss= findViewById(R.id.txt_admin_accesss);
        txt_logg= findViewById(R.id.txt_logg);
        txt_start_recording= findViewById(R.id.txt_start_recording);
        txt_stop_recording= findViewById(R.id.txt_stop_recording);
        txt_profile= findViewById(R.id.txt_profile);
        utilities= new Utilities(this);
        invitation_section = new ArrayList<>();
        progress = new ProgressDialog(MainActivity.this);
        progress.setMessage("loading");
        progress.setCancelable(false);
        IS_RECORDING_START=  preferenceHelper.GetBoolean("IS_RECORDING_START",false);
        isAdmin=  preferenceHelper.GetBoolean("IS_ADMIN",false);

        if (isAdmin){
            txt_invites.setVisibility(View.VISIBLE);
        }else {
            txt_invites.setVisibility(View.GONE);
        }



        userid= preferenceHelper.GetInt("USER_ID", 0);

//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            workRequest = new PeriodicWorkRequest.Builder(Worker.class, 15, TimeUnit.MINUTES).build();
        //}

        if (isAdmin){
            if (IS_RECORDING_START){

                preferenceHelper.SaveBoolean("IS_RECORDING_START", true);
                txt_start_recording.setVisibility(View.GONE);
                txt_stop_recording.setVisibility(View.VISIBLE);
                txt_admin_accesss.setVisibility(View.VISIBLE);
                txt_logg.setVisibility(View.VISIBLE);
                txt_status.setText("Accepted");
                txt_status.setTextColor(Color.parseColor("#00D100"));
            }else{
                preferenceHelper.SaveBoolean("IS_RECORDING_START", false);
                txt_start_recording.setVisibility(View.VISIBLE);
                txt_stop_recording.setVisibility(View.GONE);
                txt_admin_accesss.setVisibility(View.VISIBLE);
                txt_logg.setVisibility(View.VISIBLE);
                txt_status.setText("Declined");
                txt_status.setTextColor(Color.parseColor("#FE0000"));
            }
        }else{
            if (IS_RECORDING_START){

                preferenceHelper.SaveBoolean("IS_RECORDING_START", true);
                txt_start_recording.setVisibility(View.GONE);
                txt_stop_recording.setVisibility(View.VISIBLE);
                txt_admin_accesss.setVisibility(View.VISIBLE);
                txt_logg.setVisibility(View.VISIBLE);
                txt_status.setText("Accepted");
                txt_status.setTextColor(Color.parseColor("#00D100"));
            }else{
                preferenceHelper.SaveBoolean("IS_RECORDING_START", false);
                txt_start_recording.setVisibility(View.VISIBLE);
                txt_stop_recording.setVisibility(View.GONE);
                txt_admin_accesss.setVisibility(View.GONE);
                txt_logg.setVisibility(View.GONE);
                txt_status.setText("Declined");
                txt_status.setTextColor(Color.parseColor("#FE0000"));
            }
        }


        txt_start_recording.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startProjection();

              //  WorkManager.getInstance().cancelWorkById(workRequest.getId());
            }
        });

        txt_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
                startActivity(intent);
            }
        });

        txt_stop_recording.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final Dialog dialog = new Dialog(MainActivity.this);
                dialog.setContentView(R.layout.row_dialogs);
                Button btn_stop_recording =  dialog.findViewById(R.id.btn_logout);
                Button btn_later =  dialog.findViewById(R.id.btn_later);
                TextView txt_dialog_header =  dialog.findViewById(R.id.txt_dialog_header);
                TextView txt_dialog_main =  dialog.findViewById(R.id.txt_dialog_main);

                btn_stop_recording.setText("YES");
                txt_dialog_header.setText("STOP RECORDING");
                txt_dialog_main.setText("Are you sure you want to stop this recording ?");

                btn_stop_recording.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (isAdmin){
                            preferenceHelper.SaveBoolean("IS_RECORDING_START", false);
                            Logger(userid,"RECORDING_STOP");
                            txt_start_recording.setVisibility(View.VISIBLE);
                            txt_stop_recording.setVisibility(View.GONE);
                             txt_admin_accesss.setVisibility(View.VISIBLE);
                            txt_logg.setVisibility(View.VISIBLE);
                            txt_status.setText("Declined");
                            txt_status.setTextColor(Color.parseColor("#FE0000"));
                            dialog.dismiss();
                        }else{
                            preferenceHelper.SaveBoolean("IS_RECORDING_START", false);
                            Logger(userid,"RECORDING_STOP");
                            txt_start_recording.setVisibility(View.VISIBLE);
                            txt_stop_recording.setVisibility(View.GONE);
                             txt_admin_accesss.setVisibility(View.GONE);
                            txt_logg.setVisibility(View.GONE);
                            txt_status.setText("Declined");
                            txt_status.setTextColor(Color.parseColor("#FE0000"));
                            dialog.dismiss();
                        }


                        stopProjection();
                        Intent i = new Intent(MainActivity.this, TurnedOffService.class);
                        i.setAction("TURNED_OFF");
                        startService(i);
                      //  mWorkManager.enqueue(workRequest);
                    }
                });
                btn_later.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
                dialog.show();

            }
        });

        txt_logg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final Dialog dialog = new Dialog(MainActivity.this);
                dialog.setContentView(R.layout.row_dialogs);
                Button btn_logout =  dialog.findViewById(R.id.btn_logout);
                Button btn_later =  dialog.findViewById(R.id.btn_later);
                TextView txt_dialog_header =  dialog.findViewById(R.id.txt_dialog_header);
                TextView txt_dialog_main =  dialog.findViewById(R.id.txt_dialog_main);

                btn_logout.setText("YES");
                txt_dialog_header.setText("USER LOGGS");
                txt_dialog_main.setText("Do you want to see your Loggs?");

                btn_logout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if (isAdmin){
                            Intent intent = new Intent(MainActivity.this, InvitesActivity.class);
                            intent.putExtra("TYPE", "LOGG");
                            startActivity(intent);
                            dialog.dismiss();
                        }else{
                            Intent intent = new Intent(MainActivity.this, LoggActivity.class);
                            intent.putExtra("ID", userid);
                            startActivity(intent);
                            dialog.dismiss();
                        }
                    }
                });
                btn_later.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
                dialog.show();

            }
        });

        txt_admin_accesss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    final Dialog dialog = new Dialog(MainActivity.this);
                    dialog.setContentView(R.layout.row_dialogs);
                    Button btn_logout = dialog.findViewById(R.id.btn_logout);
                    Button btn_later = dialog.findViewById(R.id.btn_later);
                    TextView txt_dialog_header = dialog.findViewById(R.id.txt_dialog_header);
                    TextView txt_dialog_main = dialog.findViewById(R.id.txt_dialog_main);

                    btn_logout.setText("YES");
                    txt_dialog_header.setText("ADMIN ACCESS");
                    txt_dialog_main.setText("Do you want to see your Activities?");

                    btn_logout.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            if (isAdmin){
                                Intent intent = new Intent(MainActivity.this, InvitesActivity.class);
                                intent.putExtra("TYPE", "GALLERY");
                                startActivity(intent);
                                dialog.dismiss();
                            }else{
                                Intent intent = new Intent(MainActivity.this, GalleryActivity.class);
                                intent.putExtra("ID", userid);
                                startActivity(intent);
                                dialog.dismiss();
                            }
                        }
                    });
                    btn_later.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                        }
                    });
                    dialog.show();

            }
        });

//        txt_admin_accesss.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                IS_RECORDING_START=  preferenceHelper.GetBoolean("IS_RECORDING_START",false);
//
//                if (IS_RECORDING_START) {
//                    final Dialog dialog = new Dialog(MainActivity.this);
//                    dialog.setContentView(R.layout.row_dialogs);
//                    Button btn_logout = dialog.findViewById(R.id.btn_logout);
//                    Button btn_later = dialog.findViewById(R.id.btn_later);
//                    TextView txt_dialog_header = dialog.findViewById(R.id.txt_dialog_header);
//                    TextView txt_dialog_main = dialog.findViewById(R.id.txt_dialog_main);
//
//                    btn_logout.setText("YES");
//                    txt_dialog_header.setText("ADMIN ACCESS");
//                    txt_dialog_main.setText("Do you want to see your Activities?");
//
//                    btn_logout.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//
//                            if (isAdmin){
//                                Intent intent = new Intent(MainActivity.this, InvitesActivity.class);
//                                intent.putExtra("TYPE", "GALLERY");
//                                startActivity(intent);
//                                dialog.dismiss();
//                            }else{
//                                Intent intent = new Intent(MainActivity.this, GalleryActivity.class);
//                                intent.putExtra("ID", userid);
//                                startActivity(intent);
//                                dialog.dismiss();
//                            }
//                        }
//                    });
//                    btn_later.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//                            dialog.dismiss();
//                        }
//                    });
//                    dialog.show();
//
//
//                } else {
//                    Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
//                    startActivity(intent);
//
//            }
//            }
//        });

        txt_invites.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final Dialog dialogInvite = new Dialog(MainActivity.this);
                dialogInvite.setContentView(R.layout.row_dialog_box);
                Button btn_send =  dialogInvite.findViewById(R.id.btn_send);
                Button btn_cancel =  dialogInvite.findViewById(R.id.btn_cancel);
                EditText edt_invitation =  dialogInvite.findViewById(R.id.edt_invitation);
                dialogInvite.setCancelable(false);
                invitation_section.add(edt_invitation);
                btn_send.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (utilities.EdittextFieldsValidationResult(invitation_section).equals("Success")) {
                            if (isValidEmailId(edt_invitation.getText().toString().trim())) {
                                if (JsonUtils.isNetworkAvailable(MainActivity.this)) {
                                    if (progress!=null){
                                        progress.show();
                                    }
                                    SendingInvitations sendingInvitations = new SendingInvitations();
                                    sendingInvitations.setEmail(edt_invitation.getText().toString());
                                    sendingInvitations.setAdminId(userid);

                                    apiInterface.PostInvitation(sendingInvitations).enqueue(new Callback<SendingInvitations>() {
                                        @Override
                                        public void onResponse(Call<SendingInvitations> call, Response<SendingInvitations> response) {
                                            SendingInvitations result = response.body();

                                            int statusCode = response.code();

                                            if (statusCode == 200) {
                                                progress.dismiss();
                                                dialogInvite.dismiss();
                                                Toast.makeText(MainActivity.this, result.message, Toast.LENGTH_SHORT).show();
                                            } else if (statusCode==400){
                                                progress.dismiss();
                                                dialogInvite.dismiss();

                                                Gson gson = new Gson();
                                                SendingInvitations errorResponse = null;
                                                try {
                                                    errorResponse = gson.fromJson(response.errorBody().string(), SendingInvitations.class);
                                                } catch (IOException e) {
                                                    e.printStackTrace();
                                                }
                                                Toast.makeText(MainActivity.this, errorResponse.message, Toast.LENGTH_SHORT).show();

                                            }else {
                                                if (progress!=null){
                                                    progress.dismiss();
                                                }
                                                dialogInvite.dismiss();
                                                Toast.makeText(MainActivity.this, "try again", Toast.LENGTH_SHORT).show();

                                            }
                                        }

                                        @Override
                                        public void onFailure(Call<SendingInvitations> call, Throwable t) {
                                            if (progress!=null){
                                                progress.dismiss();
                                            }
                                            dialogInvite.dismiss();
                                            Toast.makeText(MainActivity.this, "try again", Toast.LENGTH_SHORT).show();

                                        }
                                    });
                                }else {
                                    Toast.makeText(MainActivity.this, "Check internet connection", Toast.LENGTH_SHORT).show();
                                }
                            }else {
                                Toast.makeText(MainActivity.this, "Invalid Email Address", Toast.LENGTH_SHORT).show();
                            }
                        }

                    }
                });
                btn_cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialogInvite.dismiss();
                    }
                });
                dialogInvite.show();

            }
        });

        txt_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final Dialog dialog = new Dialog(MainActivity.this);
                dialog.setContentView(R.layout.row_dialogs);
                Button btn_logout =  dialog.findViewById(R.id.btn_logout);
                Button btn_later =  dialog.findViewById(R.id.btn_later);
                btn_logout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                stopProjection();
//                mWorkManager.enqueue(workRequest);
                    dialog.dismiss();
                stopProjection();
                Intent i = new Intent(MainActivity.this, TurnedOffService.class);
                i.setAction("TURNED_OFF");
                startService(i);

                Logger(userid,"LOGOUT");
                preferenceHelper.SaveBoolean("IS_LOGGED_IN",false);
                preferenceHelper.SaveBoolean("IS_RECORDING_START", false);
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();

                }
                });
                btn_later.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                dialog.dismiss();
                }
                });
                dialog.show();

            }
        });
    }

    public void Logger(int user_id,String user_action){

        Logg logg = new Logg();
        logg.setUserId(user_id);
        logg.setAction(user_action);

        apiInterface.ActionLogg(logg).enqueue(new Callback<Logg>() {
            @Override
            public void onResponse(Call<Logg> call, Response<Logg> response) {

                int statusCode = response.code();

                if (statusCode == 200) {
                } else {
                }
            }

            @Override
            public void onFailure(Call<Logg> call, Throwable t) {

            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                preferenceHelper.SaveBoolean("IS_RECORDING_START", true);
                Logger(userid,"RECORDING_START");
                txt_start_recording.setVisibility(View.GONE);
                txt_stop_recording.setVisibility(View.VISIBLE);
                txt_admin_accesss.setVisibility(View.VISIBLE);
                txt_logg.setVisibility(View.VISIBLE);
                txt_status.setText("Accepted");
                txt_status.setTextColor(Color.parseColor("#00D100"));
                Intent intent = new Intent(MainActivity.this, TurnedOffService.class);
                intent.setAction("TURNED_ON");
                startService(intent);
                startService(ScreenCaptureService.getStartIntent(this, resultCode, data));
            }
        }
    }

    private void startProjection() {

        MediaProjectionManager mProjectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mProjectionManager.createScreenCaptureIntent(), REQUEST_CODE);
    }

    private void stopProjection() {
            startService(ScreenCaptureService.getStopIntent(this));
    }

    private boolean isValidEmailId(String email){

        return Pattern.compile("^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$").matcher(email).matches();
    }
}