package com.example.goliatheye.Constructors;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class SendingInvitations implements Serializable {

    @SerializedName("email")
    String email;
    @SerializedName("message")
    public String message;

    @SerializedName("adminId")
    int adminId;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getAdminId() {
        return adminId;
    }

    public void setAdminId(int adminId) {
        this.adminId = adminId;
    }
}
