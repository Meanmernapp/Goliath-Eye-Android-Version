package com.example.goliatheye;

import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.goliatheye.Constructors.Logg;
import com.example.goliatheye.Constructors.Login;
import com.example.goliatheye.Constructors.Menu;
import com.example.goliatheye.Constructors.Register;
import com.example.goliatheye.Utils.APIClient;
import com.example.goliatheye.Utils.APIInterface;
import com.example.goliatheye.Utils.Constant;
import com.google.gson.Gson;    
import com.tmclients.technoutils.PreferenceHelper;
import com.tmclients.technoutils.Utilities;

import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class LoginActivity extends AppCompatActivity {

    Button btn_login;
    TextView btn_new_account,txt_forgotpassword;
    APIInterface apiInterface;
   public ProgressDialog progress;
    EditText edt_email,edt_password;
    PreferenceHelper preferenceHelper;
    Utilities utilities;
    ArrayList<EditText> login_section;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btn_login= findViewById(R.id.btn_login);
        btn_new_account= findViewById(R.id.btn_new_account);
        txt_forgotpassword= findViewById(R.id.txt_forgotpassword);
        edt_email= findViewById(R.id.edt_email);
        edt_password= findViewById(R.id.edt_password);
        preferenceHelper= new PreferenceHelper(this,"GOLIATH APPLICATION");

        apiInterface = APIClient.getClient().create(APIInterface.class);
        progress = new ProgressDialog(LoginActivity.this);
        progress.setMessage("loading");
        progress.setCancelable(false);

        utilities= new Utilities(this);
        login_section= new ArrayList<>();
        login_section.add(edt_email);
        login_section.add(edt_password);


        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (utilities.EdittextFieldsValidationResult(login_section).equals("Success")) {

                if (isValidEmailId(edt_email.getText().toString().trim())) {
                    if(progress != null){
                        progress.show();
                    }

                    Login employee = new Login();
                    employee.setEmail(edt_email.getText().toString());
                    employee.setPassword(edt_password.getText().toString());

                    apiInterface.Login(employee).enqueue(new Callback<Login>() {
                        @Override
                        public void onResponse(Call<Login> call, Response<Login> response) {
                            Login result = response.body();

                            int statusCode = response.code();

                            if (statusCode == 200) {
                                Menu menu = result.data;
                                preferenceHelper.SaveString("USERNAME", menu.getName());
                                preferenceHelper.SaveString("EMAIL", menu.getEmail());
                                preferenceHelper.SaveString("PHONE_NUMBER", menu.getPhoneNumber());
                                preferenceHelper.SaveString("PASSWORD", edt_password.getText().toString());
                                preferenceHelper.SaveInt("USER_ID", menu.getId());
                                preferenceHelper.SaveBoolean("IS_ADMIN", menu.isAdmin());
                                preferenceHelper.SaveBoolean("IS_LOGGED_IN", true);

                                Logg logg = new Logg();
                                logg.setUserId(menu.getId());
                                logg.setAction("LOGIN");

                                apiInterface.ActionLogg(logg).enqueue(new Callback<Logg>() {
                                    @Override
                                    public void onResponse(Call<Logg> call, Response<Logg> response) {

                                        int statusCode = response.code();
                                        progress.dismiss();
                                        if (statusCode == 200) {

                                            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                            startActivity(intent);
                                            finish();
                                            Toast.makeText(LoginActivity.this, result.message, Toast.LENGTH_SHORT).show();
                                        } else {
                                            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                            startActivity(intent);
                                            finish();
                                            Toast.makeText(LoginActivity.this, result.message, Toast.LENGTH_SHORT).show();

                                        }

                                    }

                                    @Override
                                    public void onFailure(Call<Logg> call, Throwable t) {
                                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                        startActivity(intent);
                                        finish();
                                        Toast.makeText(LoginActivity.this, result.message, Toast.LENGTH_SHORT).show();
                                        progress.dismiss();
                                    }
                                });

                            } else if (statusCode==400){
                                progress.dismiss();

                                Gson gson = new Gson();
                                Register errorResponse = null;
                                try {
                                    errorResponse = gson.fromJson(response.errorBody().string(), Register.class);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                GoToForgotPassword(errorResponse.message);

                            }else if (statusCode==403){
                                progress.dismiss();

                                Gson gson = new Gson();
                                Register errorResponse = null;
                                try {
                                    errorResponse = gson.fromJson(response.errorBody().string(), Register.class);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                UserNotActive(errorResponse.message);
                            }
                            else {
                                progress.dismiss();
                                GoToForgotPassword("Invalid email or passsword.");
                            }
                        }

                        @Override
                        public void onFailure(Call<Login> call, Throwable t) {

                                progress.dismiss();
                            GoToForgotPassword("Server error, try again. . ");
                        }
                    });
                }else{
        Toast.makeText(LoginActivity.this, "InValid Email Address.", Toast.LENGTH_SHORT).show();
    }
            }
            }
        });

        btn_new_account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this,SignupActivity.class);
                startActivity(intent);
            }
        });

        txt_forgotpassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, ResetPasswordActivity.class);
                startActivity(intent);
            }
        });
    }

    private boolean isValidEmailId(String email){

        return Pattern.compile("^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$").matcher(email).matches();
    }

    public void GoToForgotPassword(String txt_1){
        final Dialog dialog = new Dialog(LoginActivity.this);
        dialog.setContentView(R.layout.row_dialogs);
        Button btn_logout =  dialog.findViewById(R.id.btn_logout);
        Button btn_later =  dialog.findViewById(R.id.btn_later);
        TextView txt_dialog_header =  dialog.findViewById(R.id.txt_dialog_header);
        TextView txt_dialog_main =  dialog.findViewById(R.id.txt_dialog_main);

        btn_logout.setText("TRY AGAIN");
        txt_dialog_header.setText("LOGIN FAILED");
        txt_dialog_main.setText(txt_1);

        btn_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        btn_later.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public void UserNotActive(String txt_1){
        final Dialog dialog = new Dialog(LoginActivity.this);
        dialog.setContentView(R.layout.row_dialogs);
        Button btn_logout =  dialog.findViewById(R.id.btn_logout);
        Button btn_later =  dialog.findViewById(R.id.btn_later);
        TextView txt_dialog_header =  dialog.findViewById(R.id.txt_dialog_header);
        TextView txt_dialog_main =  dialog.findViewById(R.id.txt_dialog_main);

        btn_logout.setText("VERIFY EMAIL");
        txt_dialog_header.setText("LOGIN FAILED");
        txt_dialog_main.setText(txt_1);

        btn_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Intent intent = new Intent(LoginActivity.this, VerificationActivity.class);
                intent.putExtra("USER_EMAIL", edt_email.getText().toString());
                startActivity(intent);

            }
        });
        btn_later.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }
}