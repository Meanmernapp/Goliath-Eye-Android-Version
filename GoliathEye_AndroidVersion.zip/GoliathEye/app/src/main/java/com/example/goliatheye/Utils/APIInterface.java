package com.example.goliatheye.Utils;

import android.util.Log;

import com.example.goliatheye.Constructors.ForgotPassword;
import com.example.goliatheye.Constructors.GettingInvites;
import com.example.goliatheye.Constructors.Logg;
import com.example.goliatheye.Constructors.Login;
import com.example.goliatheye.Constructors.Register;
import com.example.goliatheye.Constructors.SS;
import com.example.goliatheye.Constructors.SendingInvitations;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;

public interface APIInterface {

    @POST("/ibl2/v1.0/users/login")
    Call<JSONResponse> Login(@Part("email") String email, @Part("password") String password);

//    @POST("/ibl/ibl/createUser")
//    Call<JSONResponse> RegisterUser(@Query("email") String email,@Query("name") String name,@Query("password") String password,@Query("phoneNumber") String phoneNumber);

    @GET("/ibl/ibl/takeScreenShots")
    Call<JSONResponse> takeSS();

    @POST("/ibl2/v1.0/users/login")
    Call<Login> Login(@Body Login login);
       //old api for registration

//    @POST("/ibl/ibl/createUser")
//    Call<Register> RegisterUser(@Body Register register);

    @POST("/ibl2/v1.0/users/createUser")
    Call<Register> RegisterUser(@Body Register register);

    @POST("/ibl2/v1.0/users/sendinvite")
    Call<SendingInvitations> PostInvitation(@Body SendingInvitations sendingInvitations);


    @POST("/ibl2/v1.0/users/forgotpassword")
    Call<ForgotPassword> ForgotPassword(@Body ForgotPassword forgotPassword);

    @POST("/ibl2/v1.0/users/logs")
    Call<Logg> ActionLogg(@Body Logg logg);

//    @GET("/employee/get-all")
//    Call<List<Employee>> getAllEmployees();

    @GET("/ibl2/v1.0/users/logs?")
    Call<List<Logg>> GetLoggs(@Query("userId") String user);

    @GET("/ibl2/v1.0/users/getinvites?")
    Call<List<GettingInvites>> Getinvites(@Query("adminId") String adminId);

    @GET("/ibl2/v1.0/users/getinvites?")
    Call<JSONResponse> GetProductDetail(@Query("adminId") int adminId);

    @GET("/ibl2/v1.0/users/screenshot?")
    Call<List<SS>> GetScreenShots(@Query("userId") int user);

    @GET("/ibl2/v1.0/users/verifyemail?")
    Call<SS> GetVerified(@Query("email") String email,@Query("code") String code);



}
