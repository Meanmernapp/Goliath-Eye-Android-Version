package com.example.goliatheye;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.goliatheye.Adapters.InvitesAdapter;
import com.example.goliatheye.Constructors.GettingInvites;
import com.example.goliatheye.Utils.APIClient;
import com.example.goliatheye.Utils.APIInterface;
import com.example.goliatheye.Utils.JSONResponse;
import com.tmclients.technoutils.PreferenceHelper;

import java.util.ArrayList;
import java.util.List;

public class InvitesActivity extends AppCompatActivity {

    PreferenceHelper preferenceHelper;
    APIInterface apiInterface;
    int userid;
    RecyclerView recycler_cart;
    InvitesAdapter invitesAdapter;
    ArrayList<GettingInvites> data;
    String TYPE;
    TextView txt_adminSide;
    CardView card_layout;
    boolean IS_RECORDING_START;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invites);

        Toolbar toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("Invites");

        Intent intent = getIntent();
        TYPE = intent.getStringExtra("TYPE");


        apiInterface = APIClient.getClient().create(APIInterface.class);
        preferenceHelper= new PreferenceHelper(this,"GOLIATH APPLICATION");
        IS_RECORDING_START=  preferenceHelper.GetBoolean("IS_RECORDING_START",false);
        userid= preferenceHelper.GetInt("USER_ID", 0);

        recycler_cart =findViewById(R.id.recycler);
        txt_adminSide =findViewById(R.id.txt_adminSide);
        card_layout =findViewById(R.id.card_layout);

        data= new ArrayList<>();

        if (TYPE.equals("GALLERY")){
            if (IS_RECORDING_START){
                txt_adminSide.setText("VIEW YOUR GALLERY");
            }else{
                txt_adminSide.setText("START RECORDING TO ACCESS YOUR GALLERY");
            }
            card_layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (IS_RECORDING_START){
                        Intent intent = new Intent(InvitesActivity.this, GalleryActivity.class);
                        intent.putExtra("ID", userid);
                        startActivity(intent);
                    }else{
                        Toast.makeText(InvitesActivity.this, "Kindly start your recording to access your gallery", Toast.LENGTH_SHORT).show();
                    }

                }
            });
        }else if (TYPE.equals("LOGG")){

            if (IS_RECORDING_START){
                txt_adminSide.setText("VIEW YOUR LOGS");
            }else{
                txt_adminSide.setText("START RECORDING TO ACCESS YOUR LOGS");
            }
            card_layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (IS_RECORDING_START){
                        Intent intent = new Intent(InvitesActivity.this, LoggActivity.class);
                        intent.putExtra("ID", userid);
                        startActivity(intent);
                    }else{
                        Toast.makeText(InvitesActivity.this, "Kindly start your recording to access your logs", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        recycler_cart.setHasFixedSize(false);
        recycler_cart.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        recycler_cart.setNestedScrollingEnabled(false);

        Invites(userid);

    }

    public void Invites(int  user_id){

//        lyt_loading.setVisibility(View.VISIBLE);
//        recyclerView.setVisibility(View.GONE);
        Call<JSONResponse> call = apiInterface.GetProductDetail(user_id);
        call.enqueue(new Callback<JSONResponse>() {
            @Override
            public void onResponse(Call<JSONResponse> call, Response<JSONResponse> response) {
                JSONResponse result = response.body();
                int statusCode = response.code();
                if (statusCode == 200) {
//                    recyclerView.setVisibility(View.VISIBLE);
//                    lyt_loading.setVisibility(View.GONE);
                    data = result.gettingInvites;
                    invitesAdapter = new InvitesAdapter(InvitesActivity.this, data,TYPE);
                    recycler_cart.setAdapter(invitesAdapter);
                } else {
                    Toast.makeText(InvitesActivity.this, "failed", Toast.LENGTH_SHORT).show();
//                    recyclerView.setVisibility(View.GONE);
//                    lyt_not_found.setVisibility(View.VISIBLE);
//                    lyt_loading.setVisibility(View.GONE);
                }

            }

            @Override
            public void onFailure(Call<JSONResponse> call, Throwable t) {
                call.cancel();
                Toast.makeText(InvitesActivity.this, "server error", Toast.LENGTH_SHORT).show();

//                lyt_server_error.setVisibility(View.VISIBLE);
//                recyclerView.setVisibility(View.GONE);
//                lyt_loading.setVisibility(View.GONE);
//                lyt_not_found.setVisibility(View.GONE);
            }
        });
    }

    public void tsts(String  user_id){
        apiInterface.Getinvites(user_id).enqueue(new Callback<List<GettingInvites>>() {
            @Override
            public void onResponse(Call<List<GettingInvites>> call, Response<List<GettingInvites>> response) {
                List<GettingInvites> result = response.body();

                int statusCode = response.code();

                if (statusCode == 200) {
                    data.addAll(result);
                    invitesAdapter = new InvitesAdapter(InvitesActivity.this, data,TYPE);
                    recycler_cart.setAdapter(invitesAdapter);
                }else {
                    Toast.makeText(InvitesActivity.this, "failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<GettingInvites>> call, Throwable t) {
                call.cancel();
                Toast.makeText(InvitesActivity.this, "server error", Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected (MenuItem item){
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}