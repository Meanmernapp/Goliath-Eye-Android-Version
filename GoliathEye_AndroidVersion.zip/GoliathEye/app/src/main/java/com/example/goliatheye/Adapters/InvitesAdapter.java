package com.example.goliatheye.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.goliatheye.Constructors.GettingInvites;
import com.example.goliatheye.Constructors.Logg;
import com.example.goliatheye.GalleryActivity;
import com.example.goliatheye.LoggActivity;
import com.example.goliatheye.R;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class InvitesAdapter extends RecyclerView.Adapter<InvitesAdapter.ViewHolder> {

    private Context context;
    private ArrayList<GettingInvites> data;
      String TYPE;
    public InvitesAdapter(Context context, ArrayList<GettingInvites> data , String gettype){
        this.context = context;
        this.data = data;
        this.TYPE = gettype;
    }

    @NonNull
    @Override
    public InvitesAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_invites, parent, false);
        return new InvitesAdapter.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull InvitesAdapter.ViewHolder holder, int position) {
        final GettingInvites singleitem = data.get(position);

        holder.txt_userEmail.setText(singleitem.getUserEmail());
        holder.txt_status.setText(singleitem.getInviteStatus());

        if (singleitem.getInviteStatus().equals("REJECTED")){
            holder.txt_status.setBackground(context.getResources().getDrawable(R.drawable.solid_rounded_red));
            holder.lyt_presenting.setBackgroundColor(context.getResources().getColor(R.color.ColorRed));
        } else if (singleitem.getInviteStatus().equals("ACCEPTED")){
            holder.txt_status.setBackground(context.getResources().getDrawable(R.drawable.solid_round_orange));
            holder.lyt_presenting.setBackgroundColor(context.getResources().getColor(R.color.colorOrange));
        } else if (singleitem.getInviteStatus().equals("INSTALLED")){
            holder.txt_status.setBackground(context.getResources().getDrawable(R.drawable.solid_round_green));
            holder.lyt_presenting.setBackgroundColor(context.getResources().getColor(R.color.colorGreen));
        } else if (singleitem.getInviteStatus().equals("PENDING")){
            holder.txt_status.setBackground(context.getResources().getDrawable(R.drawable.solid_round_black));
            holder.lyt_presenting.setBackgroundColor(context.getResources().getColor(R.color.black));
        }

        holder.card_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (TYPE.equals("GALLERY")){

                    if (singleitem.getInviteStatus().equals("REJECTED")){
                        Toast.makeText(context, "User has rejected your invitation. Try again.", Toast.LENGTH_SHORT).show();
                    } else if (singleitem.getInviteStatus().equals("INSTALLED")){
                        Intent intent = new Intent(context, GalleryActivity.class);
                        intent.putExtra("ID",singleitem.getId());
                        context.startActivity(intent);
                    } else if (singleitem.getInviteStatus().equals("ACCEPTED")){
                        Toast.makeText(context, "User isn't installed application yet.", Toast.LENGTH_SHORT).show();
                    } else if (singleitem.getInviteStatus().equals("PENDING")){
                        Toast.makeText(context, "User isn't accept your invitation yet.", Toast.LENGTH_SHORT).show();

                    }

                }else if (TYPE.equals("LOGG")){

                    if (singleitem.getInviteStatus().equals("REJECTED")){
                        Toast.makeText(context, "User has rejected your invitation. Try again.", Toast.LENGTH_SHORT).show();
                    } else if (singleitem.getInviteStatus().equals("INSTALLED")){
                        Intent intent = new Intent(context, LoggActivity.class);
                        intent.putExtra("ID", singleitem.getId());
                        context.startActivity(intent);
                    } else if (singleitem.getInviteStatus().equals("ACCEPTED")){
                        Toast.makeText(context, "User isn't installed application yet.", Toast.LENGTH_SHORT).show();
                    } else if (singleitem.getInviteStatus().equals("PENDING")){
                        Toast.makeText(context, "User isn't accept your invitation yet.", Toast.LENGTH_SHORT).show();

                    }

                }

            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView txt_userEmail,txt_status;
        LinearLayout lyt_presenting;
        CardView card_layout;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txt_userEmail = itemView.findViewById(R.id.txt_userEmail);
            txt_status = itemView.findViewById(R.id.txt_status);
            card_layout = itemView.findViewById(R.id.card_layout);
            lyt_presenting = itemView.findViewById(R.id.lyt_presenting);

        }
    }
}
