package com.example.goliatheye;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.example.goliatheye.Adapters.LoggAdapter;
import com.example.goliatheye.Constructors.Logg;
import com.example.goliatheye.Utils.APIClient;
import com.example.goliatheye.Utils.APIInterface;
import com.example.goliatheye.Utils.JSONResponse;
import com.tmclients.technoutils.PreferenceHelper;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoggActivity extends AppCompatActivity {

    PreferenceHelper preferenceHelper;
    APIInterface apiInterface;
    int userid;
    RecyclerView recycler_cart;
    LoggAdapter loggAdapter;
    ArrayList<Logg> data;
    boolean isAdmin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logg);

        Toolbar toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("Your Loggs");

        apiInterface = APIClient.getClient().create(APIInterface.class);
        preferenceHelper= new PreferenceHelper(this,"GOLIATH APPLICATION");
//        userid= preferenceHelper.GetInt("USER_ID", 0);
        isAdmin=  preferenceHelper.GetBoolean("IS_ADMIN",false);

        recycler_cart =findViewById(R.id.recycler);

        data= new ArrayList<>();
        Intent intent = getIntent();
        userid = intent.getIntExtra("ID",0);

        recycler_cart.setHasFixedSize(false);
        recycler_cart.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        recycler_cart.setNestedScrollingEnabled(false);

            GettingLoggs(String.valueOf(userid));

    }

    public void GettingLoggs(String  user_id){
        apiInterface.GetLoggs(user_id).enqueue(new Callback<List<Logg>>() {
            @Override
            public void onResponse(Call<List<Logg>> call, Response<List<Logg>> response) {
                List<Logg> result = response.body();

                int statusCode = response.code();

                if (statusCode == 200) {
                    data.addAll(result);
                    loggAdapter = new LoggAdapter(LoggActivity.this, data);
                    recycler_cart.setAdapter(loggAdapter);
                }else {
                    Toast.makeText(LoggActivity.this, "failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Logg>> call, Throwable t) {
                call.cancel();
                Toast.makeText(LoggActivity.this, "server error", Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected (MenuItem item){
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}